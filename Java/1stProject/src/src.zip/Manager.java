public interface Manager {
     
    abstract void add();
    abstract void remove();

}
