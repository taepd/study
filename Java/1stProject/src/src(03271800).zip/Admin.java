
public class Admin extends User{
    
    Admin(){
      setId("admin");
      setPwd("admin");
    }
}
