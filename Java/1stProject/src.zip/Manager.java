public interface Manager {
     
    public abstract void add();
    public abstract void remove();
    public abstract void save();
    public void load();

}
