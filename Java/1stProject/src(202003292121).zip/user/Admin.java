package user;
public class Admin extends User{
    
    public Admin(){
      setId("admin");
      setPwd("admin");
    }
}
